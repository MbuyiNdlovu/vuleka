<p>Dear {{ $user->firstname }},</p>

<p>You indicated that you forgot your password? Here it is: {{ $user->password }} </p>

<p>If you need any assistance please contact support@bwizerapp.com</p>

<p>Yours truly,<br />BWizerApp.com</p>