@extends('admin.app')

@section('content')

@include('admin.common.htmlheader')

		<section class="body">

			@include('admin.common.header')

			<div class="inner-wrapper">

				@include('admin.common.sidebarleft')

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>{{ $pageconfig['title'] }}</h2>

						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/admin">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>{{ $pageconfig['title'] }}</span></li>
							</ol>

							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
					<div class="row">
						<div class="col-md-12">
							<section class="panel">
								<div class="panel-body">

									{!! Messages::display() !!}

									<form id="form" method="post" enctype="multipart/form-data">
			                     	<input type="hidden" name="fp" value="1">	
			                     	<input type="hidden" name="_token" value="{{ csrf_token() }}">	

									 	<div class="form-group mb-none">
											<div class="row">
												<div class="col-sm-6 mb-lg">	
													@php 
														$fieldlabel = 'Parent Categoryid';
														$field = 'parentcategoryid';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<select name="{{ $field }}" id="{{ $field }}" class="form-control">
													{!! Helpers::get_category_options(Helpers::val($pageconfig['rs'],$field,Helpers::get($field))) !!}	
													</select>
												</div>												
											</div>
										</div>	
			                     
										<div class="form-group mb-none">
											<div class="row">
												<div class="col-sm-6 mb-lg">	
													@php 
														$fieldlabel = 'Category Name';
														$field = 'title';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<input name="{{ $field }}" required="required" id="{{ $field }}" type="text" class="form-control "  value="{{ Helpers::val($pageconfig['rs'],$field,Helpers::get($field)) }}" />
												</div>												
											</div>
										</div>

										<div class="form-group mb-none">
											<div class="row">
												<div class="col-sm-6 mb-lg">	
													@php 
														$fieldlabel = 'Category Photo';
														$field = 'uploadfile';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<input name="{{ $field }}" id="{{ $field }}" type="file" class="form-control "  value="{{ Helpers::val($pageconfig['rs'],$field,Helpers::get($field)) }}" />
												</div>												
											</div>
										</div>
									
										<div class="row">
											<div class="col-md-6">
												<button type="submit" class="btn btn-primary">Save Changes</button>
												<a href="/{{ $pageconfig['listuri'] }}" class="btn btn-primary">Cancel</a>
											</div>
										</div>
									</form>	
								</div>
							</section>
						</div>
					</div>
					<!-- end: page -->

				</section>
			</div>

			@include('admin.common.sidebarright')
		</section>

		@include('admin.common.htmlfooter')
		
	</body>
</html>
@endsection
