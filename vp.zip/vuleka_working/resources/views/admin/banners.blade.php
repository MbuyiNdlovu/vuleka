@extends('admin.app')

@section('content')

@include('admin.common.htmlheader')

		<section class="body">

			@include('admin.common.header')

			<div class="inner-wrapper">

				@include('admin.common.sidebarleft')

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>{{ $pageconfig['title'] }}</h2>

						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/admin">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>{{ $pageconfig['title'] }}</span></li>
							</ol>

							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<div class="row">
						<div class="col-md-12">
							<p><a href="/{{ $pageconfig['adduri'] }}" class="btn btn-primary pull-right">{{ $pageconfig['addtitle'] }}</a><br /></p>
						</div>
					</div>

					<!-- start: page -->
					<div class="row">
						<div class="col-md-12">
							<section class="panel">
								<div class="panel-body">

									{!! Messages::display() !!}

									@if (($pageconfig['rs'] == null) || (count($pageconfig['rs']) == 0))
										<p>There are no data to display in this view</p>
									@else
										<table class="table table-bordered table-striped mb-none" id="datatable-default">
											<thead>
												<tr>
													<th>Title</th>	
													<th>Link</th>												
													<th width="220"></th>
												</tr>
											</thead>
											<tbody>										
												@foreach ($pageconfig['rs'] as $row)
												<tr>
													<td>{{ $row->title }}</td>			
													<td>{{ $row->link }}</td>												
													<td>
														<a href="/{{ $pageconfig['edituri'] }}/{{ encrypt($row->id) }}" class="btn btn-primary btn-sm">View / Edit</a>
														&nbsp;
														<a href="/{{ $pageconfig['deleteuri'] }}/{{ encrypt($row->id) }}" class="btn btn-primary btn-sm" onclick="return confirm('Are you sure you want to delete this item?');">Delete</a>
													</td>
												</tr>
												@endforeach
											</tbody>
										</table>
									@endif
									

								</div>
							</section>
						</div>
					</div>
					<!-- end: page -->

				</section>
			</div>

			@include('admin.common.sidebarright')
		</section>

		@include('admin.common.htmlfooter')
	</body>
</html>
@endsection
