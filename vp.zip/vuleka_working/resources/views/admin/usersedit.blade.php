@extends('admin.app')

@section('content')

@include('admin.common.htmlheader')

		<section class="body">

			@include('admin.common.header')

			<div class="inner-wrapper">

				@include('admin.common.sidebarleft')

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>{{ $pageconfig['title'] }}</h2>

						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/admin">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>{{ $pageconfig['title'] }}</span></li>
							</ol>

							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
					<div class="row">
						<div class="col-md-12">
							<section class="panel">
								<div class="panel-body">

									{!! Messages::display() !!}

									<form id="form" method="post">
			                     	<input type="hidden" name="fp" value="1">	
			                     	<input type="hidden" name="_token" value="{{ csrf_token() }}">		

			                     		@if ($pageconfig['rs'] == null)
				                     		<div class="form-group mb-none">
												<div class="row">
													<div class="col-sm-6 mb-lg">	
														@php 
															$fieldlabel = 'User Role';
															$field = 'userroleid';
														@endphp												
														<label>{{ $fieldlabel }}</label>
														<select name="{{ $field }}" id="{{ $field }}" class="form-control" onchange="UserRoleSelected();">
														{!! Helpers::get_lookup_options($field,Helpers::val($pageconfig['rs'],$field,Helpers::get($field))) !!}	
														</select>
													</div>
												</div>
											</div>		
										@endif

										<div class="form-group mb-none merchantfields" style="display:none;">
											<div class="row">
												<div class="col-sm-6 mb-lg">	
													@php 
														$fieldlabel = 'Business Name';
														$field = 'businessname';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<input name="{{ $field }}" required="required" id="{{ $field }}" type="text" class="form-control "  value="{{ Helpers::val($pageconfig['rs'],$field,Helpers::get($field)) }}" />
												</div>
												<div class="col-sm-6 mb-lg">	
													@php 
														$fieldlabel = 'Category';
														$field = 'businesscategoryid';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<select name="{{ $field }}" id="{{ $field }}" class="form-control">
													{!! Helpers::get_lookup_options($field,Helpers::val($pageconfig['rs'],$field,Helpers::get($field))) !!}	
													</select>
												</div>
											</div>
										</div>

										<div class="form-group mb-none merchantfields" style="display:none;">
											<div class="row">
												<div class="col-sm-6 mb-lg">	
													@php 
														$fieldlabel = 'Website';
														$field = 'website';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<input name="{{ $field }}" id="{{ $field }}" type="text" class="form-control "  value="{{ Helpers::val($pageconfig['rs'],$field,Helpers::get($field)) }}" />
												</div>
												<div class="col-sm-6 mb-lg">	
													@php 
														$fieldlabel = 'Address';
														$field = 'businessaddress';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<input name="{{ $field }}" id="{{ $field }}" type="text" class="form-control "  value="{{ Helpers::val($pageconfig['rs'],$field,Helpers::get($field)) }}" />
												</div>
											</div>
										</div>

										<div class="form-group mb-none">
											<div class="row">
												<div class="col-sm-6 mb-lg">	
													@php 
														$fieldlabel = 'Name';
														$field = 'firstname';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<input name="{{ $field }}" required="required" id="{{ $field }}" type="text" class="form-control "  value="{{ Helpers::val($pageconfig['rs'],$field,Helpers::get($field)) }}" />
												</div>
												<div class="col-sm-6 mb-lg">	
													@php 
														$fieldlabel = 'Surname';
														$field = 'lastname';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<input name="{{ $field }}" required="required" id="{{ $field }}" type="text" class="form-control "  value="{{ Helpers::val($pageconfig['rs'],$field,Helpers::get($field)) }}" />
												</div>
											</div>
										</div>

										<div class="form-group mb-none">
											<div class="row">
												<div class="col-sm-12 mb-lg">	
													@php 
														$fieldlabel = 'Email';
														$field = 'email';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<input name="{{ $field }}" id="{{ $field }}" type="text" class="form-control "  value="{{ Helpers::val($pageconfig['rs'],$field,Helpers::get($field)) }}" />
												</div>
											</div>
										</div>

										<div class="form-group mb-none">
											<div class="row">
												<div class="col-sm-6 mb-lg">	
													@php 
														$fieldlabel = 'Mobile';
														$field = 'mobile';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<input name="{{ $field }}" id="{{ $field }}" type="text" class="form-control "  value="{{ Helpers::val($pageconfig['rs'],$field,Helpers::get($field)) }}" />
												</div>
												<div class="col-sm-6 mb-lg merchantfields" style="display:none;">	
													@php 
														$fieldlabel = 'Business Tel';
														$field = 'businesstel';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<input name="{{ $field }}" id="{{ $field }}" type="text" class="form-control " value="{{ Helpers::val($pageconfig['rs'],$field,Helpers::get($field)) }}" />
												</div>
											</div>
										</div>

										<div class="form-group mb-none">
											<div class="row">
												<div class="col-sm-6 mb-lg">	
													@php 
														$fieldlabel = 'Password';
														$field = 'password';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<input name="{{ $field }}" id="{{ $field }}" type="password" class="form-control " />
												</div>
												<div class="col-sm-6 mb-lg">	
													@php 
														$fieldlabel = 'Confirm Password';
														$field = 'confirmpassword';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<input name="{{ $field }}" id="{{ $field }}" type="password" class="form-control " />
												</div>
											</div>
										</div>

										<div class="checkbox">
											<label>
												@php 
													$fieldlabel = 'Login Enabled';
													$field = 'enabled';
												@endphp				
												<input type="checkbox" id="enabled" name="enabled" @if (Helpers::val($pageconfig['rs'],$field,Helpers::get($field)) == '1') checked="checked" @endif value="1">
												{{ $fieldlabel }}
											</label>
										</div>

										<div class="row">
											<div class="col-md-6">
												<button type="submit" class="btn btn-primary">Save Changes</button>
												<a href="/{{ $pageconfig['listuri'] }}" class="btn btn-primary">Cancel</a>
											</div>
										</div>
									</form>	
								</div>
							</section>
						</div>
					</div>
					<!-- end: page -->

				</section>
			</div>

			@include('admin.common.sidebarright')
		</section>

		@include('admin.common.htmlfooter')

		<script>

			function UserRoleSelected()
			{				
				if($('#userroleid').val() == '2')
				{
					$('.merchantfields').show();
				}
				else
					$('.merchantfields').hide();
			}

			jQuery(document).ready(function(){
				@if (Helpers::val($pageconfig['rs'],'userroleid','') == '2')
					$('.merchantfields').show();
				@endif
			});
			

		</script>
		
	</body>
</html>
@endsection
