<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Aloha!</title>

<style type="text/css">
    * {
        font-family: Verdana, Arial, sans-serif;
    }
    table{
        font-size: x-small;
    }
    tfoot tr td{
        font-weight: bold;
        font-size: x-small;
    }

    .gray {
        background-color: lightgray
    }
</style>

</head>
<body>

  <table width="100%">
    <tr>
        <td valign="top"><img src="/adminassets/images/logo.png" alt="" width="150"/></td>
        <td align="right">
            <h3>Impulse</h3>
            <pre>
                ADDRESS 1
                ADDRESS 2
                ADDRESS 3
                Tel: +27 000-0000
                Fax: +27 000-0000
            </pre>
        </td>
    </tr>

  </table>

  <br/>

  <table width="100%">
    <thead style="background-color: lightgray;">
      <tr>
        <th>#</th>
        <th>Description</th>
        <th>Quantity</th>
        <th>Unit Price</th>
        <th>Total</th>
      </tr>
    </thead>
    <tbody>

      <tr>
        <th scope="row">1</th>
        <td>{{ $rs[0]->title }}</td>												
        <td align="right">1</td>
        <td align="right">R {{ number_format($rs[0]->impulseprice,2) }}</td>
        <td align="right">R {{ number_format($rs[0]->impulseprice,2) }}</td>
      </tr>    
    
    </tbody>

    <tfoot>
        <tr>
            <td colspan="3"></td>
            <td align="right">Subtotal</td>
            <td align="right">R {{ number_format($rs[0]->impulseprice,2) }}</td>
        </tr>
        <tr>
            <td colspan="3"></td>
            <td align="right">VAT</td>
            <td align="right">R {{ number_format($rs[0]->impulseprice - ($rs[0]->impulseprice / 1.15),2) }}</td>
        </tr>
        <tr>
            <td colspan="3"></td>
            <td align="right">Total</td>
            <td align="right" class="gray">R {{ number_format($rs[0]->impulseprice,2) }}</td>
        </tr>
    </tfoot>
  </table>

</body>
</html>