@extends('admin.app')

@section('content')

@include('admin.common.htmlheader')

		<section class="body">

			@include('admin.common.header')

			<div class="inner-wrapper">

				@include('admin.common.sidebarleft')

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>{{ $pageconfig['title'] }}</h2>

						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/admin">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>{{ $pageconfig['title'] }}</span></li>
							</ol>

							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
					<div class="row">
						<div class="col-md-12">
							<section class="panel">
								<div class="panel-body">

									{!! Messages::display() !!}

									<form id="form" method="post" enctype="multipart/form-data">
			                     	<input type="hidden" name="fp" value="1">	
			                     	<input type="hidden" name="_token" value="{{ csrf_token() }}">		
			                     
								 		<div class="form-group mb-none">
											<div class="row">
												<div class="col-sm-6 mb-lg">	
												@php 
													$fieldlabel = 'Category';
													$field = 'categoryid';
												@endphp												
												<label>{{ $fieldlabel }}</label>
												<select name="{{ $field }}" id="{{ $field }}" class="form-control">
												{!! Helpers::get_category_options(Helpers::val($pageconfig['rs'],$field,Helpers::get($field))) !!}	
												</select>
												</div>												
											</div>
										</div>

										<div class="form-group mb-none">
											<div class="row">
												<div class="col-sm-6 mb-lg">	
													@php 
														$fieldlabel = 'Product Name';
														$field = 'title';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<input name="{{ $field }}" required="required" id="{{ $field }}" type="text" class="form-control "  value="{{ Helpers::val($pageconfig['rs'],$field,Helpers::get($field)) }}" />
												</div>												
											</div>
										</div>

										<div class="form-group mb-none">
											<div class="row">
												<div class="col-sm-6 mb-lg">	
													@php 
														$fieldlabel = 'Description';
														$field = 'description';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<textarea name="{{ $field }}" id="{{ $field }}" type="text" class="form-control ">{{ Helpers::val($pageconfig['rs'],$field,Helpers::get($field)) }}</textarea>
												</div>												
											</div>
										</div>

										<div class="form-group mb-none">
											<div class="row">
												<div class="col-sm-6 mb-lg">	
													@php 
														$fieldlabel = 'Barcode';
														$field = 'barcode';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<input name="{{ $field }}" required="required" id="{{ $field }}" type="text" class="form-control "  value="{{ Helpers::val($pageconfig['rs'],$field,Helpers::get($field)) }}" />
												</div>												
											</div>
										</div>

										<div class="form-group mb-none">
											<div class="row">
												<div class="col-sm-6 mb-lg">	
													@php 
														$fieldlabel = 'Vendor Price';
														$field = 'vendorprice';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<input name="{{ $field }}" required="required" id="{{ $field }}" type="number" class="form-control "  value="{{ Helpers::val($pageconfig['rs'],$field,Helpers::get($field)) }}" />
												</div>												
											</div>
										</div>

										<div class="form-group mb-none">
											<div class="row">
												<div class="col-sm-6 mb-lg">	
													@php 
														$fieldlabel = 'Retail Price';
														$field = 'retailprice';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<input name="{{ $field }}" required="required" id="{{ $field }}" type="number" class="form-control "  value="{{ Helpers::val($pageconfig['rs'],$field,Helpers::get($field)) }}" />
												</div>												
											</div>
										</div>

										<div class="form-group mb-none">
											<div class="row">
												<div class="col-sm-6 mb-lg">	
													@php 
														$fieldlabel = 'Discounted Price';
														$field = 'discountedprice';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<input name="{{ $field }}" id="{{ $field }}" type="number" class="form-control "  value="{{ Helpers::val($pageconfig['rs'],$field,Helpers::get($field)) }}" />
													<em>Leave as 0 / empty to indicate that no special is running on this product.</em>
												</div>												
											</div>
										</div>

										<div class="form-group mb-none">
											<div class="row">
												<div class="col-sm-6 mb-lg">	
													@php 
														$fieldlabel = 'Product Photo';
														$field = 'uploadfile';
														$displayfield = 'photo';
													@endphp												
													<label>{{ $fieldlabel }}</label>
													<input name="{{ $field }}" id="{{ $field }}" type="file" class="form-control "  value="{{ Helpers::val($pageconfig['rs'],$field,Helpers::get($field)) }}" />
													@if (Helpers::val($pageconfig['rs'],$displayfield,Helpers::get($displayfield)) != '') <img height="150" src="/uploads/{{ Helpers::val($pageconfig['rs'],$displayfield,Helpers::get($displayfield)) }}">@endif
												</div>												
											</div>
										</div>

										<div class="checkbox">
											<label>
												@php 
													$fieldlabel = 'Check this box if this is a product hamper to be displayed under the hampers section';
													$field = 'ishamper';
												@endphp				
												<input type="checkbox" id="ishamper" name="ishamper" @if (Helpers::val($pageconfig['rs'],$field,Helpers::get($field)) == '1') checked="checked" @endif value="1">
												{{ $fieldlabel }}
											</label>
										</div>
									
										<div class="row">
											<div class="col-md-6">
												<button type="submit" class="btn btn-primary">Save Changes</button>
												<a href="/{{ $pageconfig['listuri'] }}" class="btn btn-primary">Cancel</a>
											</div>
										</div>
									</form>	
								</div>
							</section>
						</div>
					</div>
					<!-- end: page -->

				</section>
			</div>

			@include('admin.common.sidebarright')
		</section>

		@include('admin.common.htmlfooter')
		
	</body>
</html>
@endsection
