@extends('admin.app')

@section('content')

@include('admin.common.htmlheader')

		<section class="body">

			@include('admin.common.header')

			<div class="inner-wrapper">

				@include('admin.common.sidebarleft')

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>{{ $pageconfig['title'] }}</h2>

						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/admin">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>{{ $pageconfig['title'] }}</span></li>
							</ol>

							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
					<div class="row">
						<div class="col-md-12">
							<section class="panel">
								<div class="panel-body">

									{!! Messages::display() !!}

									<form id="form" method="post">
			                     	<input type="hidden" name="fp" value="1">										

										<div class="form-group mb-lg">
											<label>E-mail Address</label>
											<input name="email" type="email" required="required" class="form-control " required value="{{ Helpers::val(session('admin'),'email',Helpers::get('email')) }}" />
										</div>

										<div class="form-group mb-none">
											<p><small>Leave your password field empty if you do not intend to change it.</small></p>
											<div class="row">
												<div class="col-sm-6 mb-lg">
													<label>Password</label>
													<input name="password" required="required" id="password" type="password" class="form-control " />
												</div>
												<div class="col-sm-6 mb-lg">
													<label>Password Confirmation</label>
													<input id="confirmpassword" type="password" class="form-control " />
												</div>
											</div>
										</div>

										<div class="row">
											<div class="col-md-6">
												<button type="button" class="btn btn-primary" onclick="Save();">Save Changes</button>
												<!--<button type="button" onclick="window.history.go(-1); return false;" class="btn btn-primary">Cancel</button>-->
											</div>
										</div>
									</form>	
								</div>
							</section>
						</div>
					</div>
					<!-- end: page -->

				</section>
			</div>

			@include('admin.common.sidebarright')
		</section>

		@include('admin.common.htmlfooter')

		<script>

			function Save()
			{
				if($('#password').val() != $('#confirmpassword').val())
				{
					alert('Your passwords don\'t match.');
					return false;
				}
				else
					$('#form').submit();
			}

		</script>
	</body>
</html>
@endsection
