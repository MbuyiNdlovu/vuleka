<?php

namespace App\Http\Controllers;
use App\Classes\SMSGatewayHelper;
use App\Classes\Lokli;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Response;
use Storage;
use URL;

class TestController extends Controller
{
    //
    public function test(Request $request)
    {
        $smsGateway = new SMSGatewayHelper;
            $smsResult = $smsGateway->send('Your Password Is:', '27836564309'); 
            var_dump($smsResult);
    }
}
