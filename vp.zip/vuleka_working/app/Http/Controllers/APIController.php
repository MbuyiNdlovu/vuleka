<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Response;
use App\Lookup;
use App\User;
use App\Category;
use App\Product;
use App\Favorite;
use App\Order;
use App\Orderitem;
use App\Log;
use App\Mystock;
use App\Survey;
use App\Competition;
use App\Feedback;
use App\Banner;
use App\Classes\AppHelper;
use App\Classes\Helpers;
use URL;
use App\Mail\ForgotPassword;
use Illuminate\Support\Facades\Mail;
use App\Classes\SMSGatewayHelper;

class APIController extends Controller
{
    public function get_lookups(Request $request)
    {
        if($request->input('sections'))
        {
            $query = DB::table('lookups');
            $query->whereRaw('lookuptype = \'' . $request->input('lookuptype') . '\' and sections like \'%' . $request->input('sections') . '%\'');
            $rs = $query->get();
        }
        else if($request->input('lookupextra1'))
            $rs = Lookup::where(['lookuptype' => $request->input('lookuptype'),'lookupextra1' => $request->input('lookupextra1')])->get();        
        else if($request->input('lookuptype'))
            $rs = Lookup::where(['lookuptype' => $request->input('lookuptype')])->get();
        else
            $rs = Lookup::get();

        $this->response = array(
            'data' => json_encode($rs),
            'success' => false,
            'message' => ''
        );

        $response = Response::json($this->response);
        return $response;
    }
    
    public function register_user(Request $request)
    {
        $message = '';
        $success = true;
        $data = null;

        $user = User::where(['mobile' => $request->input('mobile')])->get();       
        if(count($user) == 0)
        { 
            if($request->input('userroleid') == 2)
                $enabled = 0;
            else
                $enabled = 1;
            $data = User::create([            
                'userroleid' => $request->input('userroleid'), // user
                'firstname' => $request->input('firstname'),
                'lastname' => $request->input('lastname'),
                'email' => $request->input('email'),
                'mobile' => $request->input('mobile'),
                'mobile2' => $request->input('mobile2'),
                'businessname' => $request->input('businessname'),
                'businesstel' => $request->input('businesstel'),
                'businessaddress' => $request->input('businessaddress'),
                'businessgpslat' => $request->input('businessgpslat'),
                'businessgpslng' => $request->input('businessgpslng'),
                'profileimage' => $request->input('profileimage'),
                'group' => $request->input('group'),
                'yearofbirth' => $request->input('yearofbirth'),
                'occupation' => $request->input('occupation'),
                'password' => $request->input('password'),            
                'deviceid' => $request->input('deviceid'),            
                'showedwelcome' => null,
                'enabled' => $enabled
            ]);
        }
        else
        {
            $message = 'Another user is already registered with the same mobile number.';
            $success = false;
        }

        $this->response = array(
            'data' => json_encode($data),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    }        
    
    public function login_user(Request $request)
    {
        $message = '';
        $success = true;
        $data = null;

        DB::enableQueryLog(); 
        $user = User::where(['mobile' => $request->input('mobile'),'password' => $request->input('password')])->get();        
        Log::create(['detail' => json_encode(DB::getQueryLog())]);
        if(count($user) >= 1)       
        {
            if($user[0]->enabled != '1')
            {
                $success = false;
                $message = 'Your account is pending verification.';    
            }
            else
            {
                if($request->input('deviceid') != '')
                {
                    $user[0]->deviceid = $request->input('deviceid');
                    $user[0]->save();
                }

                $data = $user[0];
                $success = true;
                $message = '';       
            }               
        }
        else
        {
            $success = false;
            $message = 'Invalid mobile number or password.';
        }

        $this->response = array(
            'data' => json_encode($data),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    }    

    public function social_login(Request $request)
    {	
    	$success = false;
    	$message = '';
    	$data = null;

        $rs = User::where(['email' => $request->input('email'),
                               'userroleid' => $request->input('userroleid'),
                               'enabled' => 1
                             ])->get();
    	if(count($rs) == 0)
    	{    		
            if($request->input('userroleid') == 2)
                $enabled = 0;
            else
                $enabled = 1;
        	$user = User::create([
                'userroleid' => $request->input('userroleid'), // user
                'firstname' => $request->input('firstname'),
                'lastname' => $request->input('lastname'),
                'email' => $request->input('email'),
                'mobile' => $request->input('mobile'),
                'mobile2' => $request->input('mobile2'),
                'businessname' => $request->input('businessname'),
                'businesstel' => $request->input('businesstel'),
                'businessaddress' => $request->input('businessaddress'),
                'businessgpslat' => $request->input('businessgpslat'),
                'businessgpslng' => $request->input('businessgpslng'),
                'profileimage' => $request->input('profileimage'),
                'group' => $request->input('group'),
                'yearofbirth' => $request->input('yearofbirth'),
                'occupation' => $request->input('occupation'),
                'password' => $request->input('password'),            
                'deviceid' => $request->input('deviceid'),            
                'showedwelcome' => null,
                'enabled' => $enabled
            ]);
            
            $rs = User::where(['email' => $request->input('email'),
                               'userroleid' => $request->input('userroleid')
                             ])->get();
    	}

        $success = true;
        $message = '';

        if($request->input('deviceid') != '')
            $rs[0]->deviceid = $request->input('deviceid');
        $rs[0]->save();
        
        $data = $rs[0];

    	$response = array(
         'data' => json_encode($data),
         'success' => $success,
         'message' => $message
      	);
      	return Response::json($response);
    }

    public function update_user(Request $request)
    {
        $message = '';
        $success = true;
        $data = null;    
        
        if($request->input('id') != '')
        {
            $user = User::where(['id' => $request->input('id')])->get();
            $user[0]->firstname = $request->input('firstname');
            $user[0]->lastname = $request->input('lastname');
            $user[0]->email = $request->input('email');
            if(trim($request->input('password')) != '')
                $user[0]->password = trim($request->input('password'));            
            $user[0]->mobile = $request->input('mobile');
            $user[0]->mobile2 = $request->input('mobile2');            
            $user[0]->businessname = $request->input('businessname');            
            $user[0]->businesstel = $request->input('businesstel');            
            $user[0]->businessaddress = $request->input('businessaddress');            
            $user[0]->businessgpslat = $request->input('businessgpslat');            
            $user[0]->businessgpslng = $request->input('businessgpslng');            
            $user[0]->profileimage = $request->input('profileimage');            
            $user[0]->group = $request->input('group');            
            $user[0]->yearofbirth = $request->input('yearofbirth');            
            $user[0]->occupation = $request->input('occupation');            
            $user[0]->deviceid = $request->input('deviceid');                      
            $user[0]->surveysjson = $request->input('surveysjson');   
            $user[0]->competitionjson = $request->input('competitionjson');   
            $user[0]->showedwelcome = $request->input('showedwelcome');               
            $user[0]->save();
            $data = $user[0];
        }
     
        $this->response = array(
            'data' => json_encode($data),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    }  

    public function get_media(Request $request)
    {
        $path = storage_path('uploads/' . $request->route('data'));
        return response()->download($path);
    }   

    public function send_password(Request $request)
    {
        $message = '';
        $success = true;
        $data = null;

        $user = User::where(['mobile' => $request->input('mobile')])->get();        
        if(count($user) >= 1)       
        {
            $data = $user[0];
            //Mail::to($user[0]->email)->send(new ForgotPassword($user[0]));    
            $smsGateway = new SMSGatewayHelper;
            $smsResult = $smsGateway->send('Your Password Is:' . $user[0]->password, $user[0]->mobile); 

            $success = true;
            $message = '';                      
        }
        else
        {
            $success = false;
            $message = 'Invalid mobile number.';
        }

        $this->response = array(
            'data' => json_encode($data),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    } 

    public function save_category(Request $request)
    {
        $message = '';
        $success = true;
        $data = null;    
        
        if($request->input('id') != '')
        {
            $category = Category::where(['id' => $request->input('id')])->get();
            $category[0]->title = $request->input('title');
            $category[0]->save();
            $data = $category[0];
        }
        else
        {
            $data = Category::create([            
                'subjectid' => $request->input('subjectid'),
                'title' => $request->input('title'),
            ]);
        }
     
        $this->response = array(
            'data' => json_encode($data),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    } 

    public function list_categories(Request $request)
    {
        $message = '';
        $success = true;
        $data = null;

        $data = Category::get();            

        $this->response = array(
            'data' => json_encode($data),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    }

    public function delete_category(Request $request)
    {
        $message = '';
        $success = true;
        $data = null;

        Category::where(['id' => $request->input('id')])->delete();

        $this->response = array(
            'data' => json_encode($data),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    }

    public function upload_media(Request $request)
    {
        if(move_uploaded_file($_FILES['File1']['tmp_name'],'uploads//' . $_POST['filename']))
            echo 'OK';
        else
            echo 'ERROR';
    }

    public function list_products(Request $request)
    {
        $message = '';
        $success = true;
        $data = null;

        if($request->input('search'))
        {
            $query = DB::table('products');
            $query->whereRaw('title like \'%' . $request->input('search') . '%\' or description like \'%' . $request->input('search') . '%\' or barcode like \'%' . $request->input('search') . '%\'');                 
            $data = $query->get();   
        }
        else if($request->input('myfavorite'))
        {
            $query = DB::table('products');
            $query->join('favorites', 'favorites.productid', '=', 'products.id');
            $query->selectRaw('distinct products.*,1 as myfavorite');                    
            $data = $query->get();   
        }
        else if($request->input('specialproduct'))
        {
            $query = DB::table('products');
            $query->whereRaw('discountedprice != 0');
            $data = $query->get();
        }
        else
            $data = Product::get();

        $this->response = array(
            'data' => json_encode($data),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    }

    public function list_category_products(Request $request)
    {
        $message = '';
        $success = true;
        $data = null;

        $data = Product::where(['categoryid' => $request->input('id')])->get();            

        $this->response = array(
            'data' => json_encode($data),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    }

    public function list_my_stock(Request $request)
    {
        $message = '';
        $success = true;
        $data = null;

        $query = DB::table('products');
        $query->join('mystock', 'mystock.productid', '=', 'products.id');
        $query->whereRaw('mystock.userid = ' . $request->input('id'));                    
        $data = $query->get();   

        $this->response = array(
            'data' => json_encode($data),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    }

    public function list_homeview_products(Request $request)
    {
        $message = '';
        $success = true;
        $data = array();

        $query = DB::table('products');
        $query->selectRaw('products.*');
        $query->join('orderitems', 'orderitems.productid', '=', 'products.id');
        $query->join('orders', 'orders.id', '=', 'orderitems.orderid');
        $query->whereRaw('orders.userid = ' . $request->input('id'));                    
        $rs = $query->get();   
        /*$recentlyordered = array();
        foreach($rs as $row)
        {
            if(!in_array($row,$recentlyordered))
                $recentlyordered[] = $row;
        }        
        $category1 = array(
            'title' => 'Recently Purchased',
            'products' => $recentlyordered
        );
        $data[] = $category1;*/

        $query = DB::table('products');
        $query->selectRaw('products.*');
        $query->whereRaw('products.ishamper = 1');                    
        $rs = $query->get();   
        $category2 = array(
            'title' => 'Hampers',
            'products' => $rs
        );
        $data[] = $category2;

        $query = DB::table('products');
        $query->selectRaw('products.*');
        $query->whereRaw('products.discountedprice > 0');                    
        $rs = $query->get();   
        $category2 = array(
            'title' => 'Promotions',
            'products' => $rs
        );
        $data[] = $category2;

        $categories = Category::get();   
        foreach($categories as $cat)
        {
            $category3 = array(
                'title' => $cat->title,
                'photo' => $cat->photo,
                'products' => Product::where(['categoryid' => $cat->id])->get()
            );
            $data[] = $category3;
        }
        $this->response = array(
            'data' => json_encode($data),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    }

    public function toggle_favorite(Request $request)
    {
        $message = '';
        $success = true;
        $data = null;

        $rs = Favorite::where(['userid' => $request->input('userid'),'productid' => $request->input('productid')])->get();
        if($rs->count() == 0)
        {
            $data = Favorite::create([            
                'userid' => $request->input('userid'), // user
                'productid' => $request->input('productid')]);
        }
        else
        {
            Favorite::where(['userid' => $request->input('userid'),'productid' => $request->input('productid')])->delete();
            $data = null;
        }

        $this->response = array(
            'data' => json_encode($data),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    }

    public function create_order(Request $request)
    {
        $message = '';
        $success = true;
        $data = null;

        $order = Order::create([  
            'userid' => $request->input('userid'),
            'orderstatusid' => $request->input('orderstatusid'),
            'ordertypeid' => $request->input('ordertypeid'),
            'totalprice' => $request->input('totalprice'),
            'storeid' => Helpers::get('storeid',null),
        ]);
        
        $ordertotal = 0;
        foreach($request->input('orderitems') as $orderitem)
        {        
            $orderitem = Orderitem::create([  
                'orderid' => $order['id'],
                'productid' => $orderitem['productid'],
                'qty' => $orderitem['qty'],
                'unitprice' => $orderitem['unitprice'],
            ]);

            $ordertotal += ($orderitem['unitprice'] * $orderitem['qty']);
        }

        if($request->input('ordertypeid') == 10) // POS
        {
            
        }

        $this->response = array(
            'data' => json_encode($order),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    }

    public function update_mystock(Request $request)
    {
        $message = '';
        $success = true;
        $data = null;

        if($request->input('id'))
            $stock = Mystock::where(['id' => $request->input('id')])->get();
        else
            $stock = Mystock::where(['productid' => $request->input('productid'),'userid' => $request->input('userid')])->get();

        if($stock->count() == 1)
        {
            $stock[0]->qty = $request->input('qty');
            $stock[0]->markuppercent = $request->input('markuppercent');
            $stock[0]->save();
            $data = $stock[0];
        }

        $this->response = array(
            'data' => json_encode($data),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    }

    public function list_shops(Request $request)
    {
        $message = '';
        $success = true;
        $data = null;

        $query = DB::table('users');
        if($request->input('businessname') != '')
            $query->whereRaw('(businessaddress like \'%' . $request->input('businessname') . '%\' or businessname like \'%' . $request->input('businessname') . '%\') and userroleid = 2');                    
        else
            $query->whereRaw('userroleid = 2');                    
        $data = $query->get();   

        $this->response = array(
            'data' => json_encode($data),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    }

    public function list_surveys(Request $request)
    {
        $message = '';
        $success = true;
        $data = null;

        $data = Survey::get();  

        $this->response = array(
            'data' => json_encode($data),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    }

    public function list_competitions(Request $request)
    {
        $message = '';
        $success = true;
        $data = null;

        $data = Competition::get();  

        $this->response = array(
            'data' => json_encode($data),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    }

    public function store_feedback(Request $request)
    {
        $message = '';
        $success = true;
        $data = null;

        $data = Feedback::create([  
            'userid' => $request->input('userid'),
            'feedbacktypeid' => $request->input('feedbacktypeid'),
            'content' => $request->input('content'),
        ]);    

        $this->response = array(
            'data' => json_encode($data),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    }

    public function list_banners(Request $request)
    {
        $message = '';
        $success = true;
        $data = null;

        $data = Banner::get();            

        $this->response = array(
            'data' => json_encode($data),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    }

    public function list_orders(Request $request)
    {
        $message = '';
        $success = true;
        $data = null;

        $data = Order::where(['userid' => $request->input('id')])->get();            

        $this->response = array(
            'data' => json_encode($data),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    }

    public function list_orderitems(Request $request)
    {
        $message = '';
        $success = true;
        $data = null;

        $data = Orderitem::where(['orderid' => $request->input('id')])->get();            

        $query = DB::table('orderitems');
        $query->join('products', 'orderitems.productid', '=', 'products.id');
        $query->selectRaw('distinct orderitems.*,products.title as disp_name');  
        $query->where(['orderid' => $request->input('id')]);
        $data = $query->get();   

        $this->response = array(
            'data' => json_encode($data),
            'success' => $success,
            'message' => $message
        );

        $response = Response::json($this->response);
        return $response;
    }
}
