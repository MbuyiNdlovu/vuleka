<?php

namespace App\Http\Controllers;

use Request;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use Illuminate\Routing\UrlGenerator;

class QRController extends Controller
{
    //

    public function qr_code(Request $request)
    {
        echo QrCode::size(250)->generate(Request::url());
    }
}
