<?php

namespace App\Http\Controllers;

use Request;
use Illuminate\Routing\UrlGenerator;
use App\Log;
use App\Order;
use App\Orderitem;
use App\Transaction;
use App\Mystock;

class PaymentController extends Controller
{
    protected $url;

    public function __construct(UrlGenerator $url)
    {
        $this->url = $url;
    }

    public function checkout(Request $request)
    {
        // Construct variables 
        $cartTotal = 100;// This amount needs to be sourced from your application
        $testingMode = true;

        $orderid = Request::segment(2);

        $data = array(
            // Merchant details
            'merchant_id' => '10000100',
            'merchant_key' => '46f0cd694581a',

            // Vuleka LIVE
            //'merchant_id' => '13516216',
            //'merchant_key' => 'jdzvshdvi0dmh',

            'return_url' => $this->url->to('checkout_success'),
            'cancel_url' => $this->url->to('checkout_cancel'),
            'notify_url' => $this->url->to('checkout_notify'),
            // Buyer details
            'name_first' => 'First Name',
            'name_last'  => 'Last Name',
            'email_address'=> 'valid@email_address.com',
            // Transaction details
            'm_payment_id' => $orderid, //Unique payment ID to pass through to notify_url
            // Amount needs to be in ZAR
            // If multicurrency system its conversion has to be done before building this array
            'amount' => number_format( sprintf( "%.2f", $cartTotal ), 2, '.', '' ),
            'item_name' => 'Item Name',
            'item_description' => 'Item Description',
            'custom_int1' => '9586', //custom integer to be passed through           
            'custom_str1' => 'custom string is passed along with transaction to notify_url page'
        );        

        // Create parameter string
        $pfOutput = '';
        foreach( $data as $key => $val )
        {
            if(!empty($val))
            {
                $pfOutput .= $key .'='. urlencode( trim( $val ) ) .'&';
            }
        }
        // Remove last ampersand
        $getString = substr( $pfOutput, 0, -1 );
        //Uncomment the next line and add a passphrase if there is one set on the account 
        //$passPhrase = '';
        if( isset( $passPhrase ) )
        {
            $getString .= '&passphrase='. urlencode( trim( $passPhrase ) );
        }   
        $data['signature'] = md5( $getString );
        
        $pfHost = $testingMode ? 'sandbox.payfast.co.za' : 'www.payfast.co.za';
        $htmlForm = '<form name="theform" action="https://'.$pfHost.'/eng/process" method="post">'; 
        foreach($data as $name=> $value)
        { 
            $htmlForm .= '<input name="'.$name.'" type="hidden" value="'.$value.'" />'; 
        } 
        //$htmlForm .= '<input type="submit" value="Pay Now" /></form>'; 

        $htmlForm .= '<script>document.theform.submit();</script>';
        echo $htmlForm;
    }

    public function success(Request $request)
    {
        echo 'Please wait...';
    }

    public function cancel(Request $request)
    {
        echo 'Please wait...';
    }

    public function notify(Request $request)
    {
        $transaction = Transaction::create([  
            'm_payment_id' => $_POST['m_payment_id'],
            'pf_payment_id' => $_POST['pf_payment_id'],
            'payment_status' => $_POST['payment_status'],
            'item_name' => $_POST['item_name'],
            'item_description' => $_POST['item_description'],
            'amount_gross' => $_POST['amount_gross'],
            'amount_fee' => $_POST['amount_fee'],
            'amount_net' => $_POST['amount_net']
        ]);
        
        $order = Order::where(['id' => $_POST['m_payment_id']])->get();
        if(count($order) == 1)
        {
            $order[0]->transactionid = $transaction->id;
            if($_POST['payment_status'] == 'COMPLETE')
                $order[0]->orderstatusid = 5;
            $order[0]->save();

            $orderitems = OrderItem::where(['orderid' => $order[0]->id])->get();
            
            foreach($orderitems as $orderitem)
            {
                $mystock = Mystock::where(['userid' => $order[0]->userid,'productid' => $orderitem['productid']])->get();
                if(count($mystock) == 1)
                {
                    $mystock[0]->qty = $mystock[0]->qty + $orderitem['qty'];
                    $mystock[0]->save();
                }
                else
                {
                    Mystock::create([  
                        'productid' => $orderitem['productid'],
                        'userid' => $order[0]->userid,
                        'qty' => $orderitem['qty'],
                        'markuppercent' => 10,
                        'sellingprice' => $orderitem['unitprice'] * 1.1,          
                    ]);
                }
            }

            echo 'OK';
        }
        else    
            echo 'Oops! Something went wrong!';
    }
}
