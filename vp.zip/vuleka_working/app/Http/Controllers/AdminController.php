<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Lookup;
use App\Category;
use App\Product;
use App\Survey;
use App\Banner;
use App\Competition;
use App\Order;
use App\Orderitem;
use App\Transaction;
use App\Classes\Messages;
use App\Classes\Helpers;
use URL;
use DB;
use Response;
use View;
use Image;
use Input;
use PDF;

class AdminController extends Controller
{
    //

    public function login(Request $request)
    {   
        //if(Helpers::checklogin('admin','/admin')) return redirect('admin/users');   

    	if($request->input('fp') == '1')
    	{
    		$user = User::where(['email' => $request->input('email'),'password' => $request->input('password'),'userroleid' => 1])->get();
    		if(count($user) == 0)
    			Messages::error('Invalid email address or password.');
    		else
    		{
    			session(['admin' => $user[0]]);
    			return redirect('admin/analytics');		
    		}
    	}
    	return view('admin.login');
    }

    public function resetpassword(Request $request)
    {   
    
        if($request->input('fp') == '1')
        {
            $user = User::where(['email' => $request->input('email'),'userroleid' => 1])->get();
            if(count($user) == 0)
                Messages::error('You have not entered a valid email address.');
            else
            {
                //AdminHelpers::sendresetpasswordlink($request->input('email'));
                Messages::success('A link to reset your password was emailed to the address supplied.');
                return redirect('admin');     
            }
        }
        return view('admin.resetpassword');
    }

    public function logout()
    {
        session()->flush();
        return redirect('admin');
    }

    public function myprofile(Request $request)
    {
        if(!Helpers::checklogin('admin','/admin')) return;

        $pageconfig = [
            'title' => 'My Profile',
        ];

        if($request->input('fp') == '1')
        {
            User::where('id', session('admin')->id)
                  ->update([
                        'email' => Helpers::get('email'),
                        'password' => md5(Helpers::get('password'))
                    ]);
            Messages::success('Profile details updated successfully!');
        }

        return view('admin.myprofile',[ 'pageconfig' => $pageconfig ]);
    }

    public function users(Request $request)
    {
        if(!Helpers::checklogin('admin','/admin')) return;

        $pageconfig = [
            'title' => 'Users',
            'addtitle' => 'Add User',
            'adduri' => 'admin/users/add',
            'edituri' => 'admin/users/edit',
            'historyuri' => 'admin/users/history',
            'notificationuri' => 'admin/users/notification',
            'deleteuri' => 'admin/users/delete',
            'listuri' => 'admin/users',
            'addview' => 'admin.usersedit',
            'listview' => 'admin.users',
            'historyview' => 'admin.usershistory',
            'merchanthistoryview' => 'admin.merchanthistory',
            'notificationview' => 'admin.usersnotification',
            'addmsg' => 'User added successfully!',
            'editmsg' => 'User updated successfully!',
            'deletemsg' => 'User deleted successfully!',
            'notificationsentmsg' => 'Notification sent successfully!',
            'rs' => null
        ];

        if ($request->is($pageconfig['adduri'])) {
            
            if($request->input('fp') == '1')
            {                 
                 User::create([
                        'userroleid' => Helpers::get('userroleid',null),
                        'firstname' => Helpers::get('firstname',null),
                        'lastname' => Helpers::get('lastname',null),
                        'email' => Helpers::get('email',null),
                        'mobile' => Helpers::get('mobile',null),
                        'mobile2' => Helpers::get('mobile2'),
                        'password' => Helpers::get('password'),
                        'businessname' => Helpers::get('businessname'),
                        'businesstel' => Helpers::get('businesstel'),
                        'businessaddress' => Helpers::get('businessaddress'),                        
                        'businessgpslat' => Helpers::get('businessgpslat'),
                        'businessgpslng' => Helpers::get('businessgpslng'),
                        'group' => Helpers::get('group'),
                        'yearofbirth' => Helpers::get('yearofbirth'),
                        'occupation' => Helpers::get('occupation'),
                        'enabled' => Helpers::get('enabled',null),
                    ]);

                Messages::success($pageconfig['addmsg']); 
                return redirect($pageconfig['listuri']);    
            }
            else
            {
                return view($pageconfig['addview'], [ 
                    'pageconfig' => $pageconfig  
                ]);
            }
        }
        else if ($request->is($pageconfig['edituri'] . '/*')) 
        {
            $id = decrypt($request->segment(4));
            if($request->input('fp') == '1')
            {
                $olduser = User::where('id', $id)->get();

                User::where('id', $id)
                  ->update([
                        'firstname' => Helpers::get('firstname',null),
                        'lastname' => Helpers::get('lastname',null),
                        'email' => Helpers::get('email',null),
                        'mobile' => Helpers::get('mobile',null),
                        'mobile2' => Helpers::get('mobile2'),
                        'businessname' => Helpers::get('businessname'),
                        'businesstel' => Helpers::get('businesstel'),
                        'businessaddress' => Helpers::get('businessaddress'),
                        'businessgpslat' => Helpers::get('businessgpslat',null),
                        'businessgpslng' => Helpers::get('businessgpslng',null),
                        'group' => Helpers::get('group',null),
                        'yearofbirth' => Helpers::get('yearofbirth'),
                        'occupation' => Helpers::get('occupation'),                        
                        'enabled' => Helpers::get('enabled')   
                    ]);

                if((Helpers::get('password') != '') && (Helpers::get('password') != Helpers::get('confirmpassword')))
                {
                    Messages::error('Passwords mismatch.');        
                    $rs = User::where('id',$id)->get();
                    $pageconfig['rs'] = $rs[0];
                    return view($pageconfig['addview'], [ 
                        'pageconfig' => $pageconfig  
                    ]);
                }
                else if(Helpers::get('password') != '')
                {
                    User::where('id', $id)
                        ->update([
                        'password' => Helpers::get('password'),                        
                    ]);   
                }

                if(($olduser[0]->enabled != '1') && (Helpers::get('enabled') == '1'))
                {
                    if($olduser[0]->deviceid != '')
                    {
                        $userlist = [];
                        $userlist[] = $olduser[0]->deviceid;
                        Helpers::sendpush($userlist,'Your Vuleka account was approved and activated!',null);
                    }
                }

                Messages::success($pageconfig['editmsg']); 
                return redirect($pageconfig['listuri']);     
            }
            else
            {
                $rs = User::where('id',$id)->get();
                $pageconfig['rs'] = $rs[0];
                return view($pageconfig['addview'], [ 
                    'pageconfig' => $pageconfig  
                ]);
            }
        }
        else if ($request->is($pageconfig['deleteuri'] . '/*')) 
        {
            $id = decrypt($request->segment(4));
            User::where('id',$id)->delete();
            Messages::success($pageconfig['deletemsg']); 
            return redirect($pageconfig['listuri']);     
        }       

        $rs = User::get();
        $pageconfig['rs'] = $rs;

        return view($pageconfig['listview'], [ 
            'pageconfig' => $pageconfig  
        ]);
    }
    
    public function analytics(Request $request)
    {
        if(!Helpers::checklogin('admin','/admin')) return;
    
        /*$rs =  DB::table('purchases')
                    ->select(DB::raw('SUM(impulseprice) as total'))
                    ->where(['paymentstatusid' => 17])
                    ->get();*/
        $totalimpulses = 0;
        $totalprofit = 0;

        /*$rs =  DB::table('stats')
        ->join('users','users.id','=','stats.userid')
        ->select(DB::raw('distinct stats.userid'))
        ->whereRaw('users.userroleid = 3 and date(stats.created_at) = current_date')
        ->get();*/
        $totalvisitors = 0;

        $totalmerchants = 0;
        $avgvisitors = 0;
        $avgmerchants = 0;

        /*
        $rs =  DB::table('purchases')
        ->select(DB::raw('SUM(impulseprice) as total'))
        ->whereRaw('paymentstatusid = 17 and date(created_at) = current_date')
        ->get();*/
        $todaysorders = 0;

        $rsuser = User::where(['userroleid' => 3])->get();
        $rsmerchant = User::where(['userroleid' => 2])->get();

        $pageconfig = [
            'title' => 'Analytics',
            'usercount' => count($rsuser),
            'merchantcount' => count($rsmerchant),
            'totalimpulses' => $totalimpulses,
            'totalprofit' => $totalprofit,
            'totalvisitors' => $totalvisitors,
            'totalmerchants' => $totalmerchants,
            'avgvisitors' => $avgvisitors,
            'avgmerchants' => $avgmerchants,
            'todaysorders' => $todaysorders
        ];

        return view('admin.analytics',[ 'pageconfig' => $pageconfig ]);
    }   

    public function receipt(Request $request)
    {
        $id = decrypt($request->segment(3));
        $rs =  DB::table('purchases')
                ->join('users', 'users.id', '=', 'purchases.userid')
                ->join('impulses', 'impulses.id', '=', 'purchases.impulseid')
                ->select('purchases.*','impulses.title','users.businessname','users.firstname','users.lastname','users.email')
                ->where(['purchases.id' => $id])
                ->get();

        $pdf = PDF::loadView('admin.invoice', [ 'rs' => $rs ]);
        return $pdf->download('invoice.pdf');
    }
    
    public function categories(Request $request)
    {
        if(!Helpers::checklogin('admin','/admin')) return;

        $pageconfig = [
            'title' => 'Categories',
            'addtitle' => 'Add Category',
            'adduri' => 'admin/categories/add',
            'edituri' => 'admin/categories/edit',
            'historyuri' => 'admin/categories/history',
            'deleteuri' => 'admin/categories/delete',
            'listuri' => 'admin/categories',
            'addview' => 'admin.categoriesedit',
            'listview' => 'admin.categories',
            'addmsg' => 'Category added successfully!',
            'editmsg' => 'Category updated successfully!',
            'deletemsg' => 'Category deleted successfully!',
            'rs' => null
        ];

        /* Start handling the file upload */
        $file = $request->file('uploadfile');
        $filename = "";
        if($file)
        {
           $extension = $file->clientExtension();
           $filename = Helpers::guid();

           $success = false;
           $message = '';

           if((strtoupper($extension) == 'JPEG') || (strtoupper($extension) == 'JPG') || (strtoupper($extension) == 'BMP') || (strtoupper($extension) == 'PNG'))
           {
                Image::make(Input::file('uploadfile'))->save('uploads//' . $filename . '.jpg');
                Image::make(Input::file('uploadfile'))->fit(300,200)->save('uploads//' . $filename . '_thumb.jpg');
                $filename .= '.jpg';
           }        
           else
           {    
                Messages::error('Invalid image file type.'); 
           }                    
        }
        /* End handling the file upload */

        if ($request->is($pageconfig['adduri'])) {
            
            if($request->input('fp') == '1')
            {                 
                 Category::create([
                        'title' => Helpers::get('title',null),        
                        'photo' => $filename,              
                        'parentcategoryid' => Helpers::get('parentcategoryid',null),     
                    ]);

                Messages::success($pageconfig['addmsg']); 
                return redirect($pageconfig['listuri']);    
            }
            else
            {
                return view($pageconfig['addview'], [ 
                    'pageconfig' => $pageconfig  
                ]);
            }
        }
        else if ($request->is($pageconfig['edituri'] . '/*')) 
        {
            $id = decrypt($request->segment(4));
            if($request->input('fp') == '1')
            {
                Category::where('id', $id)
                  ->update([
                        'title' => Helpers::get('title',null),                    
                        'parentcategoryid' => Helpers::get('parentcategoryid',null),                    
                    ]);          
                    
                if($filename != "")
                {
                    Category::where('id', $id)
                    ->update([
                            'photo' => $filename
                        ]);      
                }

                Messages::success($pageconfig['editmsg']); 
                return redirect($pageconfig['listuri']);     
            }
            else
            {
                $rs = Category::where('id',$id)->get();
                $pageconfig['rs'] = $rs[0];
                return view($pageconfig['addview'], [ 
                    'pageconfig' => $pageconfig  
                ]);
            }
        }
        else if ($request->is($pageconfig['deleteuri'] . '/*')) 
        {
            $id = decrypt($request->segment(4));
            Category::where('id',$id)->delete();
            Messages::success($pageconfig['deletemsg']); 
            return redirect($pageconfig['listuri']);     
        }       
        
        $rs = Category::get();
        $pageconfig['rs'] = $rs;

        return view($pageconfig['listview'], [ 
            'pageconfig' => $pageconfig  
        ]);
    }

    public function products(Request $request)
    {
        if(!Helpers::checklogin('admin','/admin')) return;

        $pageconfig = [
            'title' => 'Products',
            'addtitle' => 'Add Product',
            'adduri' => 'admin/products/add',
            'edituri' => 'admin/products/edit',
            'historyuri' => 'admin/products/history',
            'deleteuri' => 'admin/products/delete',
            'listuri' => 'admin/products',
            'addview' => 'admin.productsedit',
            'listview' => 'admin.products',
            'addmsg' => 'Product added successfully!',
            'editmsg' => 'Product updated successfully!',
            'deletemsg' => 'Product deleted successfully!',
            'rs' => null
        ];

        /* Start handling the file upload */
        $file = $request->file('uploadfile');
        $filename = "";
        if($file)
        {
           $extension = $file->clientExtension();
           $filename = Helpers::guid();

           $success = false;
           $message = '';

           if((strtoupper($extension) == 'JPEG') || (strtoupper($extension) == 'JPG') || (strtoupper($extension) == 'BMP') || (strtoupper($extension) == 'PNG'))
           {
                Image::make(Input::file('uploadfile'))->save('uploads//' . $filename . '.jpg');
                Image::make(Input::file('uploadfile'))->fit(300,200)->save('uploads//' . $filename . '_thumb.jpg');
                $filename .= '.jpg';
           }        
           else
           {    
                Messages::error('Invalid image file type.'); 
           }                    
        }
        /* End handling the file upload */

        if ($request->is($pageconfig['adduri'])) {
            
            if($request->input('fp') == '1')
            {                 
                Product::create([
                        'title' => Helpers::get('title',null),                      
                        'categoryid' => Helpers::get('categoryid',null),        
                        'description' => Helpers::get('description',null), 
                        'barcode' => Helpers::get('barcode',null), 
                        'photo' => $filename,
                        'vendorprice' => Helpers::get('vendorprice',null), 
                        'retailprice' => Helpers::get('retailprice',null), 
                        'discountedprice' => Helpers::get('discountedprice',null), 
                        'ishamper' => Helpers::get('ishamper',null),
                    ]);

                Messages::success($pageconfig['addmsg']); 
                return redirect($pageconfig['listuri']);    
            }
            else
            {
                return view($pageconfig['addview'], [ 
                    'pageconfig' => $pageconfig  
                ]);
            }
        }
        else if ($request->is($pageconfig['edituri'] . '/*')) 
        {
            $id = decrypt($request->segment(4));
            if($request->input('fp') == '1')
            {
                Product::where('id', $id)
                  ->update([
                        'title' => Helpers::get('title',null),   
                        'categoryid' => Helpers::get('categoryid',null),        
                        'description' => Helpers::get('description',null), 
                        'barcode' => Helpers::get('barcode',null), 
                        'vendorprice' => Helpers::get('vendorprice',null), 
                        'retailprice' => Helpers::get('retailprice',null),                  
                        'discountedprice' => Helpers::get('discountedprice',null),
                        'ishamper' => Helpers::get('ishamper',null),
                    ]);    
            
                if($filename != "")
                {
                    Product::where('id', $id)
                    ->update([
                          'photo' => $filename
                      ]);      
                }

                Messages::success($pageconfig['editmsg']); 
                return redirect($pageconfig['listuri']);     
            }
            else
            {
                $rs = Product::where('id',$id)->get();
                $pageconfig['rs'] = $rs[0];
                return view($pageconfig['addview'], [ 
                    'pageconfig' => $pageconfig  
                ]);
            }
        }
        else if ($request->is($pageconfig['deleteuri'] . '/*')) 
        {
            $id = decrypt($request->segment(4));
            Product::where('id',$id)->delete();
            Messages::success($pageconfig['deletemsg']); 
            return redirect($pageconfig['listuri']);     
        }       
        
        $rs = Product::get();
        $pageconfig['rs'] = $rs;

        return view($pageconfig['listview'], [ 
            'pageconfig' => $pageconfig  
        ]);
    }

    public function surveys(Request $request)
    {
        if(!Helpers::checklogin('admin','/admin')) return;

        $pageconfig = [
            'title' => 'Surveys',
            'addtitle' => 'Add Survey',
            'adduri' => 'admin/surveys/add',
            'edituri' => 'admin/surveys/edit',
            'historyuri' => 'admin/surveys/history',
            'deleteuri' => 'admin/surveys/delete',
            'listuri' => 'admin/surveys',
            'addview' => 'admin.surveysedit',
            'listview' => 'admin.surveys',
            'addmsg' => 'Survey added successfully!',
            'editmsg' => 'Survey updated successfully!',
            'deletemsg' => 'Survey deleted successfully!',
            'rs' => null
        ];

        /* Start handling the file upload */
        $file = $request->file('uploadfile');
        $filename = "";
        if($file)
        {
           $extension = $file->clientExtension();
           $filename = Helpers::guid();

           $success = false;
           $message = '';

           if((strtoupper($extension) == 'JPEG') || (strtoupper($extension) == 'JPG') || (strtoupper($extension) == 'BMP') || (strtoupper($extension) == 'PNG'))
           {
                Image::make(Input::file('uploadfile'))->save('uploads//' . $filename . '.jpg');
                Image::make(Input::file('uploadfile'))->fit(300,200)->save('uploads//' . $filename . '_thumb.jpg');
                $filename .= '.jpg';
           }        
           else
           {    
                Messages::error('Invalid image file type.'); 
           }                    
        }
        /* End handling the file upload */

        if ($request->is($pageconfig['adduri'])) {
            
            if($request->input('fp') == '1')
            {                 
                Survey::create([
                        'detail' => Helpers::get('detail',null),                      
                        'questions' => Helpers::get('questions',null),        
                        'credit' => Helpers::get('credit',null), 
                        'activefrom' => Helpers::get('activefrom',null), 
                        'activeto' => Helpers::get('activeto',null), 
                        'photo' => $filename
                    ]);

                Messages::success($pageconfig['addmsg']); 
                return redirect($pageconfig['listuri']);    
            }
            else
            {
                return view($pageconfig['addview'], [ 
                    'pageconfig' => $pageconfig  
                ]);
            }
        }
        else if ($request->is($pageconfig['edituri'] . '/*')) 
        {
            $id = decrypt($request->segment(4));
            if($request->input('fp') == '1')
            {
                Survey::where('id', $id)
                  ->update([
                    'detail' => Helpers::get('detail',null),                      
                    'questions' => Helpers::get('questions',null),        
                    'credit' => Helpers::get('credit',null), 
                    'activefrom' => Helpers::get('activefrom',null), 
                    'activeto' => Helpers::get('activeto',null), 
                    ]);    
            
                if($filename != "")
                {
                    Survey::where('id', $id)
                    ->update([
                          'photo' => $filename
                      ]);      
                }

                Messages::success($pageconfig['editmsg']); 
                return redirect($pageconfig['listuri']);     
            }
            else
            {
                $rs = Survey::where('id',$id)->get();
                $pageconfig['rs'] = $rs[0];
                return view($pageconfig['addview'], [ 
                    'pageconfig' => $pageconfig  
                ]);
            }
        }
        else if ($request->is($pageconfig['deleteuri'] . '/*')) 
        {
            $id = decrypt($request->segment(4));
            Survey::where('id',$id)->delete();
            Messages::success($pageconfig['deletemsg']); 
            return redirect($pageconfig['listuri']);     
        }       
        
        $rs = Survey::get();
        $pageconfig['rs'] = $rs;

        return view($pageconfig['listview'], [ 
            'pageconfig' => $pageconfig  
        ]);
    }

    public function competitions(Request $request)
    {
        if(!Helpers::checklogin('admin','/admin')) return;

        $pageconfig = [
            'title' => 'Competitions',
            'addtitle' => 'Add Competition',
            'adduri' => 'admin/competitions/add',
            'edituri' => 'admin/competitions/edit',
            'historyuri' => 'admin/competitions/history',
            'deleteuri' => 'admin/competitions/delete',
            'listuri' => 'admin/competitions',
            'addview' => 'admin.competitionsedit',
            'listview' => 'admin.competitions',
            'addmsg' => 'Competition added successfully!',
            'editmsg' => 'Competition updated successfully!',
            'deletemsg' => 'Competition deleted successfully!',
            'rs' => null
        ];

        /* Start handling the file upload */
        $file = $request->file('uploadfile');
        $filename = "";
        if($file)
        {
           $extension = $file->clientExtension();
           $filename = Helpers::guid();

           $success = false;
           $message = '';

           if((strtoupper($extension) == 'JPEG') || (strtoupper($extension) == 'JPG') || (strtoupper($extension) == 'BMP') || (strtoupper($extension) == 'PNG'))
           {
                Image::make(Input::file('uploadfile'))->save('uploads//' . $filename . '.jpg');
                Image::make(Input::file('uploadfile'))->fit(300,200)->save('uploads//' . $filename . '_thumb.jpg');
                $filename .= '.jpg';
           }        
           else
           {    
                Messages::error('Invalid image file type.'); 
           }                    
        }
        /* End handling the file upload */

        if ($request->is($pageconfig['adduri'])) {
            
            if($request->input('fp') == '1')
            {                 
                Competition::create([
                        'detail' => Helpers::get('detail',null),                      
                        'questions' => Helpers::get('questions',null),        
                        'credit' => Helpers::get('credit',null), 
                        'activefrom' => Helpers::get('activefrom',null), 
                        'activeto' => Helpers::get('activeto',null), 
                        'photo' => $filename,
                    ]);

                Messages::success($pageconfig['addmsg']); 
                return redirect($pageconfig['listuri']);    
            }
            else
            {
                return view($pageconfig['addview'], [ 
                    'pageconfig' => $pageconfig  
                ]);
            }
        }
        else if ($request->is($pageconfig['edituri'] . '/*')) 
        {
            $id = decrypt($request->segment(4));
            if($request->input('fp') == '1')
            {
                Competition::where('id', $id)
                  ->update([
                        'detail' => Helpers::get('detail',null),                      
                        'questions' => Helpers::get('questions',null),        
                        'credit' => Helpers::get('credit',null), 
                        'activefrom' => Helpers::get('activefrom',null), 
                        'activeto' => Helpers::get('activeto',null), 
                    ]);    
            
                if($filename != "")
                {
                    Competition::where('id', $id)
                    ->update([
                          'photo' => $filename
                      ]);      
                }

                Messages::success($pageconfig['editmsg']); 
                return redirect($pageconfig['listuri']);     
            }
            else
            {
                $rs = Competition::where('id',$id)->get();
                $pageconfig['rs'] = $rs[0];
                return view($pageconfig['addview'], [ 
                    'pageconfig' => $pageconfig  
                ]);
            }
        }
        else if ($request->is($pageconfig['deleteuri'] . '/*')) 
        {
            $id = decrypt($request->segment(4));
            Competition::where('id',$id)->delete();
            Messages::success($pageconfig['deletemsg']); 
            return redirect($pageconfig['listuri']);     
        }       
        
        $rs = Competition::get();
        $pageconfig['rs'] = $rs;

        return view($pageconfig['listview'], [ 
            'pageconfig' => $pageconfig  
        ]);
    }

    public function orders(Request $request)
    {
        if(!Helpers::checklogin('admin','/admin')) return;

        $pageconfig = [
            'title' => 'Orders',
            'addtitle' => '',
            'adduri' => 'admin/orders/add',
            'edituri' => 'admin/orders/edit',
            'historyuri' => 'admin/orders/history',
            'deleteuri' => 'admin/orders/delete',
            'listuri' => 'admin/orders',
            'addview' => 'admin.ordersedit',
            'listview' => 'admin.orders',
            'addmsg' => 'Order added successfully!',
            'editmsg' => 'Order updated successfully!',
            'deletemsg' => 'Order deleted successfully!',
            'rs' => null
        ];

       if ($request->is($pageconfig['edituri'] . '/*')) 
        {
            $id = decrypt($request->segment(4));
            if($request->input('fp') == '1')
            {
                Order::where('id', $id)
                  ->update([
                        'orderstatusid' => Helpers::get('orderstatusid',null),   
                    ]);    
                        
                Messages::success($pageconfig['editmsg']); 
                return redirect($pageconfig['listuri']);     
            }
            else
            {
                $rs = order::where('id',$id)->get();
                $pageconfig['rs'] = $rs[0];
                return view($pageconfig['addview'], [ 
                    'pageconfig' => $pageconfig  
                ]);
            }
        }       
        
        $rs = order::get();
        $pageconfig['rs'] = $rs;

        return view($pageconfig['listview'], [ 
            'pageconfig' => $pageconfig  
        ]);
    }

    public function banners(Request $request)
    {
        if(!Helpers::checklogin('admin','/admin')) return;

        $pageconfig = [
            'title' => 'Banners',
            'addtitle' => 'Add Banner',
            'adduri' => 'admin/banners/add',
            'edituri' => 'admin/banners/edit',
            'historyuri' => 'admin/banners/history',
            'deleteuri' => 'admin/banners/delete',
            'listuri' => 'admin/banners',
            'addview' => 'admin.bannersedit',
            'listview' => 'admin.banners',
            'addmsg' => 'Banner added successfully!',
            'editmsg' => 'Banner updated successfully!',
            'deletemsg' => 'Banner deleted successfully!',
            'rs' => null
        ];

        /* Start handling the file upload */
        $file = $request->file('uploadfile');
        $filename = "";
        if($file)
        {
           $extension = $file->clientExtension();
           $filename = Helpers::guid();

           $success = false;
           $message = '';

           if((strtoupper($extension) == 'JPEG') || (strtoupper($extension) == 'JPG') || (strtoupper($extension) == 'BMP') || (strtoupper($extension) == 'PNG'))
           {
                Image::make(Input::file('uploadfile'))->save('uploads//' . $filename . '.jpg');
                Image::make(Input::file('uploadfile'))->fit(300,200)->save('uploads//' . $filename . '_thumb.jpg');
                $filename .= '.jpg';
           }        
           else
           {    
                Messages::error('Invalid image file type.'); 
           }                    
        }
        /* End handling the file upload */

        if ($request->is($pageconfig['adduri'])) {
            
            if($request->input('fp') == '1')
            {                 
                Banner::create([
                        'title' => Helpers::get('title',null),                      
                        'link' => Helpers::get('link',null),                      
                        'photo' => $filename,                        
                    ]);

                Messages::success($pageconfig['addmsg']); 
                return redirect($pageconfig['listuri']);    
            }
            else
            {
                return view($pageconfig['addview'], [ 
                    'pageconfig' => $pageconfig  
                ]);
            }
        }
        else if ($request->is($pageconfig['edituri'] . '/*')) 
        {
            $id = decrypt($request->segment(4));
            if($request->input('fp') == '1')
            {
                Banner::where('id', $id)
                  ->update([
                        'title' => Helpers::get('title',null),   
                        'link' => Helpers::get('link',null),                           
                    ]);    
            
                if($filename != "")
                {
                    Banner::where('id', $id)
                    ->update([
                          'photo' => $filename
                      ]);      
                }

                Messages::success($pageconfig['editmsg']); 
                return redirect($pageconfig['listuri']);     
            }
            else
            {
                $rs = Banner::where('id',$id)->get();
                $pageconfig['rs'] = $rs[0];
                return view($pageconfig['addview'], [ 
                    'pageconfig' => $pageconfig  
                ]);
            }
        }
        else if ($request->is($pageconfig['deleteuri'] . '/*')) 
        {
            $id = decrypt($request->segment(4));
            Banner::where('id',$id)->delete();
            Messages::success($pageconfig['deletemsg']); 
            return redirect($pageconfig['listuri']);     
        }       
        
        $rs = Banner::get();
        $pageconfig['rs'] = $rs;

        return view($pageconfig['listview'], [ 
            'pageconfig' => $pageconfig  
        ]);
    }

    public function sendmessage(Request $request)
    {
        if(!Helpers::checklogin('admin','/admin')) return;

        if($request->input('fp') == '1')
        {
            if($request->input('allusers') != '')
            {
                Helpers::sendpush(null,$request->input('allusers'),null);
                Messages::success('Message sent to all users! "' . $request->input('allusers') . '"'); 
            }
            
            if($request->input('vendors') != '')
            {
                $users  = User::where(['userroleid' => 2])->get();
                $userlist = [];
                foreach($users as $user)
                {
                    if($user->deviceid != '')
                        $userlist[] = $user->deviceid;
                }
                Helpers::sendpush($userlist,$request->input('vendors'),null);
                Messages::success('Message sent to all vendors! "' . $request->input('vendors') . '"'); 
            }

            if($request->input('consumers') != '')
            {
                $users  = User::where(['userroleid' => 3])->get();
                $userlist = [];
                foreach($users as $user)
                {
                    if($user->deviceid != '')
                        $userlist[] = $user->deviceid;
                }
                Helpers::sendpush($userlist,$request->input('consumers'),null);
                Messages::success('Message sent to all consumers! "' . $request->input('consumers') . '"'); 
            }
        }

        $pageconfig = [
            'title' => 'Send Message',
            'rs' => null
        ];

        
        $rs = Banner::get();
        $pageconfig['rs'] = $rs;

        return view('admin/sendmessage', [ 
            'pageconfig' => $pageconfig  
        ]);
    }
}
