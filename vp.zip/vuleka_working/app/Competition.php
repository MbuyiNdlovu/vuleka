<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Competition extends Model
{
    //
    protected $fillable = [
        'detail', 'photo', 'questions', 'credit', 'activefrom', 'activeto'
    ];
}
