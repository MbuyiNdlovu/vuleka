<?php

namespace App\Classes;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Collection;
use App\Log;
use App\Lookup;
use App\User;

class Apphelper {

	public function __construct()
	{
	}

    public static function arraytocommalist($arrval)
    {
        $list = '';
        foreach($arrval as $val)
        {
            if($list != '')
                $list .= ',';
            $list .= $val;
        }
        return $list;
    }

    public static function get_user($userid)
    {
        $val = User::where('id', $userid)->get();
        return $val;
    }

    public static function get_lookup_value($lookupid)
    {
        $val = Lookup::where('id', $lookupid)->get();
        if(count($val) > 0)
            return $val[0]->lookupvalue;
        else
            return '';
    }

    public static function nullie($value)
    {
    	if($value == '')
    		return null;
    	else
    		return $value;
    }

    public static function showdate($value)
    {
        if(empty($value))
            return '';
        else
            return date('Y-m-d',strtotime($value));
    }

    public static function friendlydate($value)
    {
        if(empty($value))
            return '';
        else
            return date('l, F j',strtotime($value));
    }

    public static function log($detail)
    {
        Log::create(['detail' => $detail]);
    }

    public static function limittext($text,$limit)
    {
        if(strlen($text) > $limit)
            return substr($text,0,$limit) . '...';
        else
            return $text;
    }    
}


?>
