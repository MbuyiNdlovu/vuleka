<?php // Code within app\Helpers\Helper.php

namespace App\Classes;

use DB;
use App\Lookup;

class AdminHelpers
{   
    public static function gravatar()
    {
    	if(empty(session('admin')->email))
    		return 'https://placehold.it/80x80';
    	else
    	{
    		$hash = md5(trim(strtolower(session('admin')->email)));
   			return 'https://www.gravatar.com/avatar/' . $hash;
    	}
    }
}