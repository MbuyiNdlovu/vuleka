<?php // Code within app\Helpers\Helper.php

namespace App\Classes;

use DB;
use App\Lookup;
use App\Category;

class Helpers
{       
    public static function get($fieldname, $default = '')
    {
        if(isset($_POST[$fieldname]))
            return $_POST[$fieldname];
        else
            return $default;
    }

    public static function checklogin($key,$redirect)
    {
        if(session()->has($key)) 
            return true;
        else
        {
            header('location: ' . $redirect);
            exit;
        }
    }

    public static function maxstrlen($str,$len)
    {
        if(strlen($str) > $len)
            return substr($str,0,$len) . '...';
        else
            return $str;
    }    

    public static function get_lookup_options($lookuptype,$default = null)
    {
        $html = '';

        $lookups = Lookup::where('lookuptype', $lookuptype)->get();

        foreach($lookups as $row)
        {
            if(($default != '') && ($default == $row->id))
                $html .= '<option value="' . $row->id . '" selected="selected">' . $row->lookupvalue . '</option>';
            else
                $html .= '<option value="' . $row->id . '">' . $row->lookupvalue . '</option>';
        }
        echo $html;
    }

    public static function get_category_options($default = null)
    {
        $html = '<option value="0">ROOT</option>';

        $lookups = Category::where('parentcategoryid', 0)->get();

        foreach($lookups as $row)
        {
            if(($default != '') && ($default == $row->id))
                $html .= '<option value="' . $row->id . '" selected="selected">' . $row->title . '</option>';
            else
                $html .= '<option value="' . $row->id . '">' . $row->title . '</option>';
        }
        echo $html;
    }

    public static function get_lookup_value($lookupid)
    {
        $val = Lookup::where('id', $lookupid)->get();
        if(count($val) > 0)
            return $val[0]->lookupvalue;
        else
            return '';
    }

    public static function nullie($value)
    {
    	if($value == '')
    		return null;
    	else
    		return $value;
    }

    public static function randomid()
    {
        return 'P' . rand(0,9) . rand(0,9) . rand(0,9) . rand(0,9) . rand(0,9) . rand(0,9);
    }

    public static function arrvalue($arr,$key,$nullie = false)
    {
    	if(array_key_exists($key, $arr))
    	{
    		if(($nullie) && ($arr[$key] == ''))
    			return null;
    		else
    			return $arr[$key];
    	}
    	else
    		return null;
    }

    public static function guid()
    {        
        mt_srand((double)microtime()*10000);
        $charid = strtoupper(md5(uniqid(rand(), true)));
        $hyphen = chr(45);// "-"
        $uuid = substr($charid, 0, 8).$hyphen
            .substr($charid, 8, 4).$hyphen
            .substr($charid,12, 4).$hyphen
            .substr($charid,16, 4).$hyphen
            .substr($charid,20,12);            
        return strtolower($uuid);
    }

    public static function val($record, $field, $default = '')
    {        
        if($record == null)
            return $default;    
        else if(is_object($record))
        {            
            if(property_exists($record, $field))
                return $record->$field;
            else if(isset($record->$field))
                return $record->$field;
            else
                return $default;
        }
        else if(is_array($record))
        {
            if(array_key_exists($field, $record))
                return $record[$field];
            else
                return $default;
        }
    }

    public static function contains($string, $value)
    {
        if($value == null)
            return false;
        else if(strtoupper(trim($string)) == strtoupper(trim($value)))
            return true;
        else if(strpos(strtoupper(trim($string)),strtoupper(trim($value))) === false)
            return false;
        else
            return true;
    }

    public static function showdate($value)
    {
        if(empty($value))
            return '';
        else
            return date('Y-m-d',strtotime($value));
    }

    public static function showtime($value)
    {
        if(empty($value))
            return '';
        else
            return date('H:i:s',strtotime($value));
    }

    public static function showdatetime($value)
    {
        if(empty($value))
            return '';
        else
            return date('Y-m-d H:i:s',strtotime($value));
    }

    public static function mysqltime()
    {
        return date('Y-m-d H:i:s');
    }

    public static function csharpdate($value)
    {
        return substr($value,0,10);
    }

    public static function money($value)
    {
        return 'R ' . number_format($value,2);
    }

    public static function moneyns($value)
    {
        return number_format($value,2);
    }

    public static function hoursminsonly($value)
    {
        $parts = explode(':',$value);
        if(count($parts) >= 2)
        {
            return $parts[0] . ':' . $parts[1];
        }
        else
            return $value;       
    }

    public static function ReturnDateAndTime($startdate,$starttime)
    {
        $date = strtotime($startdate);
        return date('Y-m-d',$date) . ' ' . $starttime;
    }

    public static function sendpush($id, $msg, $data)
    {
        $content = array(
            "en" => $msg
        );

        if($id != null)
        {
            $fields = array(
                'app_id' => "fdb59956-6729-4e73-b0e5-f34bbe75fdd4",
                'include_player_ids' => $id,
                'data' => $data,
                'contents' => $content
            );
        }
        else
        {
            $fields = array(
                'app_id' => "fdb59956-6729-4e73-b0e5-f34bbe75fdd4",
                'included_segments' => array('Active Users'),
                'data' => $data,
                'contents' => $content
            );
        }

        $fields = json_encode($fields);
        //print("\nJSON sent:\n");
        //print($fields);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
                                'Authorization: Basic MmVkYjgzZTAtYWYyMy00NjYxLWEzMzgtNjkzOGFkN2UzYTNm'));

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

        $response = curl_exec($ch);
        var_dump($response);
        curl_close($ch);

        //$response = sendMessage();
        //$return["allresponses"] = $response;
        //$return = json_encode( $return);

        /*print("\n\nJSON received:\n");
        print($return);
        print("\n");*/
    }
}