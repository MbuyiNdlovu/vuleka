<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    protected $fillable = [
        'userroleid', 'firstname', 'lastname', 'email', 'mobile', 'mobile2', 'password', 'businessname', 'businesstel', 'businessaddress',
        'businessgpslat', 'businessgpslng', 'profileimage', 'enabled', 'group', 'yearofbirth', 'occupation', 'deviceid', 'creditbalance',
        'surveysjson', 'competitionjson', 'showedwelcome'
    ];
}
