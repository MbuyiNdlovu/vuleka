<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mystock extends Model
{
    //
    protected $table = 'mystock';
    //
    protected $fillable = [
        'productid', 'userid', 'qty', 'markuppercent', 'sellingprice'
    ];
}
