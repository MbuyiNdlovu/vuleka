<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    //
    protected $fillable = [
        'm_payment_id', 'pf_payment_id', 'payment_status', 'item_name', 'item_description', 'amount_gross', 'amount_fee', 'amount_net'
    ];
}
