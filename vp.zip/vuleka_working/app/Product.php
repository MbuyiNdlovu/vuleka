<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable = [
        'categoryid', 'title', 'description', 'photo', 'vendorprice', 'retailprice', 'discountedprice', 'barcode', 'ishamper'
    ];
}
