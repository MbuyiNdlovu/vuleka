<?php

use Illuminate\Support\Facades\Mail;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/test', 'TestController@test');
Route::match(['get', 'post'], '/admin', 'AdminController@login');
Route::match(['get', 'post'], '/resetpassword', 'AdminController@resetpassword');
Route::get('/admin/logout', 'AdminController@logout');
Route::match(['get', 'post'], '/admin/myprofile', 'AdminController@myprofile');
Route::match(['get', 'post'], '/admin/users/{function?}/{data?}', 'AdminController@users');
Route::match(['get', 'post'], '/admin/analytics', 'AdminController@analytics');
Route::match(['get', 'post'], '/admin/products/{function?}/{data?}', 'AdminController@products');
Route::match(['get', 'post'], '/admin/banners/{function?}/{data?}', 'AdminController@banners');
Route::match(['get', 'post'], '/admin/categories/{function?}/{data?}', 'AdminController@categories');
Route::match(['get', 'post'], '/admin/surveys/{function?}/{data?}', 'AdminController@surveys');
Route::match(['get', 'post'], '/admin/competitions/{function?}/{data?}', 'AdminController@competitions');
Route::match(['get', 'post'], '/admin/orders/{function?}/{data?}', 'AdminController@orders');
Route::match(['get', 'post'], '/qr_code/{data?}', 'QRController@qr_code');
Route::match(['get', 'post'], '/admin/sendmessage/{function?}/{data?}', 'AdminController@sendmessage');

Route::match(['get', 'post'], '/checkout/{data?}', 'PaymentController@checkout');
Route::match(['get', 'post'], '/checkout_success/{data?}', 'PaymentController@success');
Route::match(['get', 'post'], '/checkout_cancel/{data?}', 'PaymentController@cancel');
Route::match(['get', 'post'], '/checkout_notify/{data?}', 'PaymentController@notify');



