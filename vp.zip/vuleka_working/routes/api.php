<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('/get_lookups', 'APIController@get_lookups');
Route::post('/register_user', 'APIController@register_user');
Route::post('/update_user', 'APIController@update_user');
Route::post('/login_user', 'APIController@login_user');
Route::post('/social_login', 'APIController@social_login');
Route::post('/send_password', 'APIController@send_password');
Route::post('/save_category', 'APIController@save_category');
Route::post('/list_categories', 'APIController@list_categories');
Route::post('/delete_category', 'APIController@delete_category');
Route::post('/list_products', 'APIController@list_products');
Route::post('/list_category_products', 'APIController@list_category_products');
Route::post('/list_my_stock', 'APIController@list_my_stock');
Route::post('/list_homeview_products', 'APIController@list_homeview_products');
Route::post('/toggle_favorite', 'APIController@toggle_favorite');
Route::post('/create_order', 'APIController@create_order');
Route::post('/update_mystock', 'APIController@update_mystock');
Route::post('/list_shops', 'APIController@list_shops');
Route::post('/list_surveys', 'APIController@list_surveys');
Route::post('/list_competitions', 'APIController@list_competitions');
Route::post('/store_feedback', 'APIController@store_feedback');
Route::post('/upload_media', 'APIController@upload_media');
Route::post('/list_banners', 'APIController@list_banners');
Route::post('/list_orders', 'APIController@list_orders');
Route::post('/list_orderitems', 'APIController@list_orderitems');
